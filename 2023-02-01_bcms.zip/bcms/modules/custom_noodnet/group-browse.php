<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td width="16%"><iframe src="http://promotions.noodnet.com/ibanner.php?id=7" width="150" height="60" scrolling="no" frameborder="0"></iframe></td>
    <td width="68%"><h1 align="center" style="border: 1 solid #0080C0">&nbsp;</h1></td>
    <td width="16%" align="right"><iframe src="http://promotions.noodnet.com/ibanner.php?id=8" width="150" height="60" scrolling="no" frameborder="0"></iframe></td>
  </tr>
  <tr>
    <td colspan="2" valign="top"><h1 align="center">&nbsp;</h1>
      <p><font size="2">To browse the Nood Group Database you have two options. You can list all
        Nood Group Items by Name or list them by Price, in either Ascending or Descending Order.</font></p>
      <div align="center">
        <center>
          <table border="0" width="400">
            <tr>
              <td width="400" bgcolor="#A0D3FA"><big><strong>Show Entire Nood Group Database</strong></big></td>
            </tr>
            <tr>
              <td width="190"><form method="POST" name="entiredb"
    action="http://noodnet.com/cgi-bin/member-entire-db-nood-group.pl" align="left">
                  <input type="hidden" name="SortType" value>
                <table border="0" width="390">
                    <tr>
                      <td width="146"><font size="2">
                        <input type="radio" value="ASC" checked name="AscDesc">
                        Ascending<br>
                        <input type="radio" name="AscDesc" value="DESC">
                        Descending</font></td>
                      <td width="236"><div align="right">
                        <p><font size="2">
                          <input type="button"
          value="List Items - Sort Name " name="EntireDB_Name" onClick="Name()">
                        </font></p>
                      </div>
                          <div align="right">
                        <p><font size="2">
                          <input type="button"
          value=" List Items - Sort Price  " name="B2" onClick="Price()">
                        </font></td>
                    </tr>
                  </table>
              </form></td>
            </tr>
          </table>
        </center>
      </div>
      <div align="center">
        <center>
          <table border="0" width="400">
            <tr>
              <td width="400" bgcolor="#A0D3FA"><big><strong>Search by Nood Group Name</strong></big></td>
            </tr>
            <tr>
              <td width="400"><form method="POST" name="search"
    action="http://noodnet.com/cgi-bin/member-search-nood-group.pl">
                  <input type="hidden" name="VTI-GROUP" value="0">
                <table border="0" width="393">
                    <tr>
                      <td width="291"><font size="2">Name :
                        <input type="text" name="name" size="24">
                        </font>
                          <div
          align="center">
                        <center>
                        <p><font size="2">
                          <input type="submit" value="Search" name="B1">
                        </font></td>
                      <td width="102" align="center"><div align="left">
                          <p><font size="2">
                            <input type="radio"
          value="ASC" checked name="AscDesc">
                            Ascending<br>
                            <input type="radio" name="AscDesc" value="DESC">
                            Descending</font></td>
                    </tr>
                  </table>
              </form></td>
            </tr>
          </table>
        </center>
      </div>      <p align="center">&nbsp;</p>
    </td>
    <td align="right" valign="top"><iframe src="http://promotions.noodnet.com/ibanner.php?id=9" width="150" height="300" scrolling="no" frameborder="0"></iframe>
        <br>
        <iframe src="http://promotions.noodnet.com/ibanner.php?id=10" width="150" height="300" scrolling="no" frameborder="0"></iframe></td>
  </tr>
  <tr>
    <td colspan="3" align="center"><iframe src="http://promotions.noodnet.com/ibanner.php?id=11" width="450" height="100" scrolling="no" frameborder="0"></iframe></td>
  </tr>
</table>