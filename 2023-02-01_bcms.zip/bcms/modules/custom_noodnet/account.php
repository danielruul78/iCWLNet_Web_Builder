<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td width="16%"><iframe src="http://promotions.noodnet.com/ibanner.php?id=7" width="150" height="60" scrolling="no" frameborder="0"></iframe></td>
    <td width="68%"><h1 align="center" style="border: 1 solid #0080C0">&nbsp;</h1></td>
    <td width="16%" align="right"><iframe src="http://promotions.noodnet.com/ibanner.php?id=8" width="150" height="60" scrolling="no" frameborder="0"></iframe></td>
  </tr>
  <tr>
    <td colspan="2" valign="top"><p><font size="2"><em>Payments can be made </em> to &quot;Nood Network Pty Ltd&quot;
either by EFT (Electronic Funds Transfer), Cheque, or Credit Card.<strong> </strong></font></p>
        <p><em><font size="2">&nbsp;</font></em></p>
        <p><font size="2"><em>Please ALWAYS include</em> your <strong>Nood Member ID number</strong> as reference when making payments. Thank you.</font></p>
        <p><font size="2">&nbsp;</font></p>
        <p><font size="2">To access Outstanding Invoices and Payment History:</font></p>
        <table border="0" width="100%" cellspacing="1">
          <tr>
            <td width="50%" valign="bottom"><form method="POST"
    action="http://noodnet.com/cgi-bin/create-invoice.pl">
                <input type="hidden" name="VTI-GROUP" value="0">
              <div align="center">
                <center>
                  <p>
                    <input
      type="submit" value="Create Outstanding Invoice" name="Create_Outstanding_Invoice">
                  </p>
                </center>
              </div>
            </form></td>
            <td width="50%" valign="bottom"><form method="POST"
    action="http://noodnet.com/cgi-bin/account-history.pl">
                <input type="hidden" name="VTI-GROUP2" value="0">
              <input type="hidden" name="VTI-GROUP2"
      value="1">
              <div align="center">
                <center>
                  <p>Month
                    <select name="HistoryMonth" size="1">
                          <option value="01">Jan</option>
                          <option value="02">Feb</option>
                          <option value="03">Mar</option>
                          <option value="04">Apr</option>
                          <option value="05">May</option>
                          <option value="06">Jun</option>
                          <option value="07">Jul</option>
                          <option value="08">Aug</option>
                          <option value="09">Sep</option>
                          <option value="10">Oct</option>
                          <option value="11">Nov</option>
                          <option value="12">Dec</option>
                        </select>
                    Year
                    <select name="HistoryYear" size="1">
                      <option value="2000">2000</option>
                      <option value="2001">2001</option>
                      <option value="2002">2002</option>
                      <option value="2003">2003</option>
                      <option value="2004">2004</option>
                      <option value="2005">2005</option>
                      <option value="2006">2006</option>
                      <option value="2007">2007</option>
                      <option value="2008">2008</option>
                      <option value="2009">2009</option>
                      <option value="2010">2010</option>
                      <option value="2011">2011</option>
                      <option value="2012">2012</option>
                      <option value="2013">2013</option>
                      <option value="2014">2014</option>
                      <option value="2015">2015</option>
                      <option value="2016">2016</option>
                      <option value="2017">2017</option>
                      <option value="2018">2018</option>
                      <option value="2019">2019</option>
                      <option value="2020">2020</option>
                    </select>
                    <br>
                    <input type="submit" value="    View Payment History    " name="View_Payment_History">
                  </p>
                </center>
              </div>
            </form></td>
          </tr>
        </table>
        <p></p></td>
    <td align="right" valign="top"><iframe src="http://promotions.noodnet.com/ibanner.php?id=9" width="150" height="300" scrolling="no" frameborder="0"></iframe>
        <br>
        <iframe src="http://promotions.noodnet.com/ibanner.php?id=10" width="150" height="300" scrolling="no" frameborder="0"></iframe></td>
  </tr>
  <tr>
    <td colspan="3" align="center"><iframe src="http://promotions.noodnet.com/ibanner.php?id=11" width="450" height="100" scrolling="no" frameborder="0"></iframe></td>
  </tr>
</table>