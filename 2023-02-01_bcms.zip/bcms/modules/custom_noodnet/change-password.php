<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td width="16%"><iframe src="http://promotions.noodnet.com/ibanner.php?id=7" width="150" height="60" scrolling="no" frameborder="0"></iframe></td>
    <td width="68%"><h1 align="center" style="border: 1 solid #0080C0">&nbsp;</h1></td>
    <td width="16%" align="right"><iframe src="http://promotions.noodnet.com/ibanner.php?id=8" width="150" height="60" scrolling="no" frameborder="0"></iframe></td>
  </tr>
  <tr>
    <td colspan="2" valign="top"><p align="center">&nbsp;</p>
      <p><font size="2">To <strong><font color="#0080C0">update your password</font></strong> simply type in your current password, and then type in your new password twice. This will
        ensure that you did not mis-type your new password.</font></p>
      <form method="POST" name="password_update" action="http://noodnet.com/cgi-bin/change-password.pl">
        <input type="hidden" name="VTI-GROUP" value="0">
        <table border="0" width="442">
          <tr>
            <td width="183"><font size="2">Existing Nood Password : </font></td>
            <td width="251"><input type="password" name="current_password" size="25"></td>
          </tr>
          <tr>
            <td width="183"><font size="2">New Password :</font></td>
            <td width="251"><input type="password" name="new_password1" size="25"></td>
          </tr>
          <tr>
            <td width="183"><font size="2">Verify New Password :</font></td>
            <td width="251"><input type="password" name="new_password2" size="25"></td>
          </tr>
        </table>
        <p>
          <input type="button" value="Submit" name="Password_Submit" onClick="CheckNewPwd()">
          <input type="reset" value="Clear" name="Clear">
        </p>
      </form>
      <p><font size="2">Note:&nbsp; If you would like <strong><font color="#0080C0">to update
        your User Details</font></strong> you will need to send an email to <a href="mailto:admin@noodnet.com">admin@noodnet.com</a> with your new details and a Nood
        Network Administrator will update your details.</font></p>
      <p><font size="2">If you would like to add a more familiar <strong><font color="#0080C0">Alias
        User ID</font></strong>, click on User Details, complete the Login Alias box, and click
        Update Details. This enables you to <font color="#0080C0"><strong>use your ID number or
          alias</strong></font> in upper or lower case when logging in.&nbsp; However, any alias
        starting with numeric 1 will not be accepted.</font></p>      <p>&nbsp;</p>
    </td>
    <td align="right" valign="top"><iframe src="http://promotions.noodnet.com/ibanner.php?id=9" width="150" height="300" scrolling="no" frameborder="0"></iframe>
        <br>
        <iframe src="http://promotions.noodnet.com/ibanner.php?id=10" width="150" height="300" scrolling="no" frameborder="0"></iframe></td>
  </tr>
  <tr>
    <td colspan="3" align="center"><iframe src="http://promotions.noodnet.com/ibanner.php?id=11" width="450" height="100" scrolling="no" frameborder="0"></iframe></td>
  </tr>
</table>