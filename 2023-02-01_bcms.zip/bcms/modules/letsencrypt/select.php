<?

?>
<form name="form1" method="post" action="">
<table>
<tr>
    <td>Domain to encrypt</td><td><input name="domain" type="text" id="domain" size="50" value="<?php print $domain;?>"></td>
</tr>
</table>
<input name="Submit" type="submit" class="loginbutton" value="Select Domain">
</form>