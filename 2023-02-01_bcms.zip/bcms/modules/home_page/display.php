<style type="text/css">
<!--
.style3 {color: #000066}
.style5 {color: #000099}
.style6 {color: #053983}
-->
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="398"><table width="386" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="446" valign="middle" class="rightColumnTops">News on Pokeralia</td>
      </tr>
      <tr>
        <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td width="89" height="28" background="<?=TEMPLATEDIR;?>images/rightTab1.gif"><div align="center" class="style3">News</div></td>
            <td width="89" background="<?=TEMPLATEDIR;?>images/rightTab2.gif"><div align="center" class="style3">Strategy</div></td>
            <td width="117" background="<?=TEMPLATEDIR;?>images/rightTab3.gif"><div align="center" class="style3">Live Tournaments</div></td>
            <td width="90" background="<?=TEMPLATEDIR;?>images/rightTab4.gif"><div align="center" class="style3">Blog</div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><p><br />
                  <span class="mainHeading">Lorem ipsumdolor sit ammet</span></p>
              <p><span class="style5"><span class="mainHeading"><img src="<?=TEMPLATEDIR;?>images/main_Image.gif" width="121" height="97" align="left" class="imagePadding1" /></span>by One-Quality</span><br />
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard <br />
                <br />
                <span class="style5"><a href="#">ReadMore</a></span></p>
          <p class="style6">More Articles</p>
          <ul>
                <li class="style6">Lorem Ipsum is simply dummy text of</li>
            <li class="style6">Lorem Ipsum is simply dummy text of</li>
            <li class="style6">Lorem Ipsum is simply dummy text of</li>
            <li class="style6">Lorem Ipsum is simply dummy text of</li>
          </ul></td>
      </tr>
    </table>
        <table width="386" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="446" valign="middle" class="rightColumnTops">On the Pokeralia Table</td>
          </tr>
          <tr>
            <td><table width="353" border="0" align="left" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="110" height="28" background="<?=TEMPLATEDIR;?>images/right_3_tab_1.gif"><div align="center" class="style3">Hand of the day</div></td>
                  <td width="125" background="<?=TEMPLATEDIR;?>images/right_3_tab_2.gif"><div align="center" class="style3">Best Table</div></td>
                  <td width="118" background="<?=TEMPLATEDIR;?>images/right_3_tab_3.gif"><div align="center" class="style3">Legendary Hands</div></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td><p><img src="<?=TEMPLATEDIR;?>images/pokerGame.gif" width="384" height="243" /><br />
            </p></td>
          </tr>
        </table>
      <br />
        <table width="386" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="446" valign="middle" class="rightColumnTops">Videos</td>
          </tr>
          <tr>
            <td><table width="353" border="0" align="left" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="110" height="28" background="<?=TEMPLATEDIR;?>images/right_3_tab_1.gif"><div align="center" class="style3">Poker Videos</div></td>
                  <td width="125" background="<?=TEMPLATEDIR;?>images/right_3_tab_2.gif"><div align="center" class="style3">Legendary Videos</div></td>
                  <td width="118" background="<?=TEMPLATEDIR;?>images/right_3_tab_3.gif"><div align="center" class="style3">Legendary Games</div></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td><p><img src="<?=TEMPLATEDIR;?>images/videoPlayer.gif" width="386" height="270" /><br />
            </p></td>
          </tr>
      </table></td>
    <td width="331" valign="top"><table width="289" border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td class="leftColumnTops">Top 5 poker Teams</td>
      </tr>
      <tr>
        <td><table width="289" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="4"><img src="<?=TEMPLATEDIR;?>images/rightBoxTop.gif" width="289" height="4" /></td>
          </tr>
          <tr>
            <td class="rightContentBorder" bgcolor="#f3f3f3"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="10%" valign="middle" class="pokerTeamList">&nbsp;</td>
                <td width="34%" valign="middle" class="pokerTeamList"><div align="center">Poker Room</div></td>
                <td width="20%" valign="middle" class="pokerTeamList"><div align="center">Rating</div></td>
                <td width="18%" valign="middle" class="pokerTeamList"><div align="center">Bonus</div></td>
                <td width="18%" valign="middle" class="pokerTeamList"><div align="center">Revew</div></td>
              </tr>
              <tr>
                <td valign="middle" class="pokerTeamList"><div align="center">1.</div></td>
                <td align="center" valign="middle" class="pokerTeamList"><img src="<?=TEMPLATEDIR;?>images/pokerGraphic_1.gif" width="87" height="33" /></td>
                <td valign="middle" class="pokerTeamList"><div align="center">8,66</div></td>
                <td valign="middle" class="pokerTeamList"><div align="center">$600</div></td>
                <td valign="middle" class="pokerTeamList"><div align="center">Review</div></td>
              </tr>
              <tr>
                <td valign="middle" class="pokerTeamList"><div align="center">2.</div></td>
                <td align="center" valign="middle" class="pokerTeamList"><img src="<?=TEMPLATEDIR;?>images/pokerGraphic_2.gif" width="87" height="32" /></td>
                <td valign="middle" class="pokerTeamList"><div align="center">8,66</div></td>
                <td valign="middle" class="pokerTeamList"><div align="center">$600</div></td>
                <td valign="middle" class="pokerTeamList"><div align="center">Review</div></td>
              </tr>
              <tr>
                <td valign="middle" class="pokerTeamList"><div align="center">3.</div></td>
                <td align="center" valign="middle" class="pokerTeamList"><img src="<?=TEMPLATEDIR;?>images/pokerGraphic_3.gif" width="87" height="33" /></td>
                <td valign="middle" class="pokerTeamList"><div align="center">8,66</div></td>
                <td valign="middle" class="pokerTeamList"><div align="center">$600</div></td>
                <td valign="middle" class="pokerTeamList"><div align="center">Review</div></td>
              </tr>
              <tr>
                <td valign="middle" class="pokerTeamList"><div align="center">4.</div></td>
                <td align="center" valign="middle" class="pokerTeamList"><img src="<?=TEMPLATEDIR;?>images/pokerGraphic_4.gif" width="87" height="32" /></td>
                <td valign="middle" class="pokerTeamList"><div align="center">8,66</div></td>
                <td valign="middle" class="pokerTeamList"><div align="center">$600</div></td>
                <td valign="middle" class="pokerTeamList"><div align="center">Review</div></td>
              </tr>
              <tr>
                <td valign="middle" class="pokerTeamList"><div align="center">5.</div></td>
                <td align="center" valign="middle" class="pokerTeamList"><img src="<?=TEMPLATEDIR;?>images/pokerGraphic_5.gif" width="87" height="31" /></td>
                <td valign="middle" class="pokerTeamList"><div align="center">8,66</div></td>
                <td valign="middle" class="pokerTeamList"><div align="center">$600</div></td>
                <td valign="middle" class="pokerTeamList"><div align="center">Review</div></td>
              </tr>
            </table>
                    <br /></td>
          </tr>
          <tr>
            <td height="3"><img src="<?=TEMPLATEDIR;?>images/rightBoxBottom.gif" width="289" height="3" /></td>
          </tr>
        </table>
              <br />
              <table width="289" border="0" align="right" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="leftColumnTops">Top 5 poker Teams</td>
                </tr>
                <tr>
                  <td><table width="289" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td height="4"><img src="<?=TEMPLATEDIR;?>images/rightBoxTop.gif" width="289" height="4" /></td>
                      </tr>
                      <tr>
                        <td class="rightContentBorder2" bgcolor="#f3f3f3"><p><img src="<?=TEMPLATEDIR;?>images/newsletterImage.gif" width="102" height="79" align="left" class="imagePadding1" />Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                            <p>Name<br />
                                <input name="textfield4" type="text" class="searchField" id="textfield4" size="35" />
                            </p>
                          <p>Email<br />
                                <input name="textfield5" type="text" class="searchField" id="textfield5" size="35" />
                                <img src="<?=TEMPLATEDIR;?>images/goButton.gif" width="47" height="20" align="top" /><br />
                          </p></td>
                      </tr>
                      <tr>
                        <td height="3"><img src="<?=TEMPLATEDIR;?>images/rightBoxBottom.gif" width="289" height="3" /></td>
                      </tr>
                    </table>
                      <table width="289" border="0" align="right" cellpadding="0" cellspacing="0">
                        <tr>
                          <td class="leftColumnTops">Top 5 poker Teams</td>
                        </tr>
                        <tr>
                          <td><table width="289" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td height="4"><img src="<?=TEMPLATEDIR;?>images/rightBoxTop.gif" width="289" height="4" /></td>
                              </tr>
                              <tr>
                                <td class="rightContentBorder2" bgcolor="#f3f3f3"><p><img src="<?=TEMPLATEDIR;?>images/pokerPlayer2.gif" width="91" height="124" align="left" class="imagePadding1" />Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to makeLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make</p>
                                    <p><strong>Search for player</strong><br />
                                        <input name="textfield6" type="text" class="searchField" id="textfield6" size="35" />
                                        <img src="<?=TEMPLATEDIR;?>images/goButton.gif" width="47" height="20" align="top" /><br />
                                  </p></td>
                              </tr>
                              <tr>
                                <td height="3"><img src="<?=TEMPLATEDIR;?>images/rightBoxBottom.gif" width="289" height="3" /></td>
                              </tr>
                          </table></td>
                        </tr>
                      </table>
                    <p>&nbsp;</p></td>
                </tr>
              </table>
          <p>&nbsp;</p></td>
      </tr>
    </table>
        <p>&nbsp;</p>
      <p>&nbsp;</p></td>
  </tr>
</table>
