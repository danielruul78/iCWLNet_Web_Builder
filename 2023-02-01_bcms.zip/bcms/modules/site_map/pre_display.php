<?php

	//print_r($domain_data);
    /*
	$site_map_page_data=array();
	$sql="SELECT * FROM content_pages WHERE domainsID=".$domain_data['id'];
	print $sql;
	$rslt=$r->RawQuery($sql);
	$num_rows=$r->NumRows($rslt);
	if($num_rows>0){
		while($content_data=$r->Fetch_Assoc()){
			$site_map_page_data[]=$content_data;
		};
	}

	
	$sql="SELECT * FROM content_pages WHERE domainsID=0";
	print $sql;
	$rslt=$r->RawQuery($sql);
	$num_rows=$r->NumRows($rslt);
	if($num_rows>0){
		while($content_data=$r->Fetch_Assoc()){
			$site_map_page_data[]=$content_data;
		};
	}
    */

	//print_r($site_map_page_data);

?>