<pre>
<?

	print_r($packagelist);
	print_r($packagesuper);



?>
</pre>