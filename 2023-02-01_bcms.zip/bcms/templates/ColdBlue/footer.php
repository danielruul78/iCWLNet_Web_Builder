
</div>

<div id="footer">
	<p id="blog-name">Copyright &copy; <?php the_time('Y'); ?> <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></p>
	<p id="webrevolutionary-link">
		<?php /* Please do not delete this small, un-obtrusive link. 
	 	I gave up my time to develop this theme for non-profit, so people such as you can use it for free. Show your support! :)
		Of course, you could simply ignore this and remove the link. */ ?>
		<a href="http://webrevolutionary.com/coldblue/">ColdBlue</a> v1.0 &mdash; A theme by <a href="http://webrevolutionary.com/">WebRevolutionary</a> &amp; <a href="http://www.forwebdesigners.com/">ForWebdesigners</a>
	</p>
</div>

<!-- ColdBlue v1.0 theme designed by WebRevolutionary.com -->

		<?php wp_footer(); ?>
</body>
</html>
