</div><!-- content -->
</div><!-- container -->
<div id="footer">
<p>
Copyright &#169; <?php print(date(Y)); ?> <a href="<?php bloginfo('url'); ?>"><span><?php bloginfo('name'); ?></span></a>
</p>
<p>
Website Design Development Hosting Programming Promotion <a href="http://creativeweblogic.net" title="Creative Web Logic">Creative Web Logic .Net</a> &bull; Powered by <a href="http://bubblecms.biz" title="Bubble CMS"> Website Builder</a>
</p>
</div>
</div><!-- body-container -->
</body>
<?php wp_footer(); ?>
</html>