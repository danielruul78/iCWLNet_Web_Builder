<?php
	$commision_level = 5.00;
    $gst_percentage = 10.00;
	$new_user_credit=0.00;
	$new_referred_user_credit=20.00;
	$referrer_user_credit=20.00;
	$Message="";
?>